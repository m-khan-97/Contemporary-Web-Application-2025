import React, { useState, useEffect } from 'react';
import Search from './search';
import Results from './searchresults';

export default function App() {

    const [darkMode, setDarkMode] = useState(false);
    const [artist, setArtist] = useState('');
    const [songs, setSongs] = useState([]);


    const background = darkMode ? 'black' : 'white',
            foreground = darkMode ? 'white': 'black';

    useEffect(() =>{
        fetch('/songs/all')
        .then(response => response.json())
        .then(data => setSongs(data))
        .catch(err => console.log("Error loading the songs:", err));
    }, []);

     async function handleSearch() {
        const route = artist.trim() 
            ? `/songs/artist/${encodeURIComponent(artist.trim())}` 
            : '/songs/all';
        try{
            const response = await fetch(route);
            const data = await response.json();
            setSongs(data);
        } catch (err){
            console.log('Error fetching the data :', err);
            setSongs([]);
        }
        
    }

    function updateMode() {
        setDarkMode(document.getElementById('mode').value=='dark');
    }
    
    return <div style={{
                backgroundColor: background, 
                color: foreground, 
                padding: '10px'
            }}>
            <Search artist={artist} setArtist={setArtist} onSearch={handleSearch} />
            
            <label htmlFor='mode'>Choose mode:</label>
            <br />
            <select id='mode' onChange={updateMode}>
            <option value='light'>Light mode</option>
            <option value='dark'>Dark mode</option>
            </select>
          <Results songs={songs} />
            </div>;

    
};
