export default function Search({artist, setArtist, onSearch}){
    return(
        <div>
            <label htmlFor='artist'>Enter an artist:</label>
            <br />
            <input id='artist' value={artist} onChange={(e) => setArtist(e.target.value)} /><br />
            <input type='button' onClick={onSearch} value='Search!' />
            <br />
        </div>
    );
}