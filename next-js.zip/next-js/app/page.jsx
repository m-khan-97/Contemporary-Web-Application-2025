import Map from './map';
import Link from 'next/link';

export default function Page() {
  return (
    <div>
      <h1>🎵 Welcome to TrackVault!</h1>
      <Map /> {/* Default map */}
      <br />
      <Link href="/search">Search for an Artist</Link>
    </div>
  );
}
