'use client';

import { useEffect, useRef } from 'react';
import dynamic from 'next/dynamic';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default function Map({ lat, lon, artist }) {
  const mapRef = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    // Only run in the browser
    if (typeof window === 'undefined') return;

    // Initialize the map only once
    if (!mapRef.current && containerRef.current) {
      mapRef.current = L.map(containerRef.current).setView([51.505, -0.09], 4);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
      }).addTo(mapRef.current);
    }

    // Update view and marker if lat/lon are provided
    if (mapRef.current && lat && lon) {
      mapRef.current.setView([lat, lon], 8);

      L.marker([lat, lon])
        .addTo(mapRef.current)
        .bindPopup(`<b>${artist}</b>`)
        .openPopup();
    }
  }, [lat, lon, artist]);

  return <div ref={containerRef} style={{ height: '500px', width: '100%' }} />;
}
