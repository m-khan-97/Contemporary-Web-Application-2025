import express from 'express';
import Database from 'better-sqlite3';
import ViteExpress from 'vite-express'
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const db = new Database(path.join(__dirname, 'wadsongs.db'));

app.get('/songs/all', (req, res) =>{
    const rows = db.prepare('SELECT * FROM wadsongs').all();
    res.json(rows);
});

app.get('/songs/artist/:name', (req, res) => {
    const name = req.params.name;
    const rows = db.prepare('SELECT * FROM wadsongs WHERE artist = ?').all(name);
    res.json(rows);
});

// const PORT = 3000;
ViteExpress.listen(app, 3000, () => {
console.log(`Production server running at 3000`);
});
