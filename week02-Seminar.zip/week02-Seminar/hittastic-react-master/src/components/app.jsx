import React, { useState, useEffect } from 'react';

export default function App() {

    const [darkMode, setDarkMode] = useState(false);
    const [artist, setArtist] = useState('');
    const [songs, setSongs] = useState([]);


    const background = darkMode ? 'black' : 'white',
            foreground = darkMode ? 'white': 'black';

    useEffect(() =>{
        fetch('/songs/all')
        .then(response => response.json())
        .then(data => setSongs(data))
        .catch(err => console.log("Error loading the songs:", err));
    }, []);
    
    return <div style={{
                backgroundColor: background, 
                color: foreground, 
                padding: '10px'
            }}>
            <label htmlFor='artist'>Enter an artist:</label>
            <br />
            <input id='artist' value={artist} onChange={(e) => setArtist(e.target.value)} /><br />
            <input type='button' onClick={search} value='Search!' />
            <br />
            <label htmlFor='mode'>Choose mode:</label>
            <br />
            <select id='mode' onChange={updateMode}>
            <option value='light'>Light mode</option>
            <option value='dark'>Dark mode</option>
            </select>
            <div id='results' style={{
                margin: '5px',
                width: '100%',
                height: '400px',
                overflow: 'auto',
                border: '1px solid ' + foreground 
            }}>
                {songs.length === 0 ? (
                    <p>No results found</p>
                ) : (
                    <ul>
                        {songs.map((song, index) => (
                            <li key={index}>
                                <strong>{song.title}</strong> by {song.artist} ({song.year})
                            </li>
                        ))}
                    </ul>
                )}
            </div>
            </div>;

     async function search() {
        const route = artist.trim() 
            ? `/songs/artist/${encodeURIComponent(artist.trim())}` 
            : '/songs/all';
        try{
            const response = await fetch(route);
            const data = await response.json();
            setSongs(data);
        } catch (err){
            console.log('Error fetching the data :', err);
            setSongs([]);
        }
        
    }

    function updateMode() {
        setDarkMode(document.getElementById('mode').value=='dark');
    }
};
