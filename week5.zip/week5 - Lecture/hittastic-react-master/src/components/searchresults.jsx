export default function Results ({songs}){
    return(
          <div id='results' style={{
                margin: '5px',
                width: '100%',
                height: '400px',
                overflow: 'auto',
                border: '1px solid black'
            }}>
                {songs.length === 0 ? (
                    <p>No results found</p>
                ) : (
                    <ul>
                        {songs.map((song, index) => (
                            <li key={index}>
                                <strong>{song.title}</strong> by {song.artist} ({song.year})
                            </li>
                        ))}
                    </ul>
                )}
            </div>
    );
}