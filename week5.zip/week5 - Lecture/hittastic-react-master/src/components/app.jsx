import React, { useState, useEffect } from 'react';
import Search from './search';
import Results from './searchresults';
import Login from './login';
import AddSong from './AddSong';
import { DarkModeContext } from './DarkModeContext';

export default function App() {

    const [darkMode, setDarkMode] = useState(false);
    const [artist, setArtist] = useState('');
    const [songs, setSongs] = useState([]);
    const [userRole, setUserRole] = useState(null);


    const background = darkMode ? 'black' : 'white',
            foreground = darkMode ? 'white': 'black';

    useEffect(() =>{
        fetch('/songs/all')
        .then(response => response.json())
        .then(data => setSongs(data))
        .catch(err => console.log("Error loading the songs:", err));
    }, []);

     async function handleSearch() {
        const route = artist.trim() 
            ? `/songs/artist/${encodeURIComponent(artist.trim())}` 
            : '/songs/all';
        try{
            const response = await fetch(route);
            const data = await response.json();
            setSongs(data);
        } catch (err){
            console.log('Error fetching the data :', err);
            setSongs([]);
        }
        
    }

    function updateMode() {
        setDarkMode(document.getElementById('mode').value=='dark');
    }
    
    return (
        <DarkModeContext.Provider value={darkMode}>
     <div style={{
                backgroundColor: background, 
                color: foreground, 
                padding: '10px'
            }}>
            {userRole ? <p>Logged in as {userRole}</p> : <Login setUserRole={setUserRole} />}
            <Search artist={artist} setArtist={setArtist} onSearch={handleSearch} />
            
            <label htmlFor='mode'>Choose mode:</label>
            <br />
            <select id='mode' onChange={updateMode}>
            <option value='light'>Light mode</option>
            <option value='dark'>Dark mode</option>
            </select>
          <Results songs={songs} />
          <AddSong userRole={userRole} />
            </div>
        </DarkModeContext.Provider>
        );
    
};
