import express from 'express';
import Database from 'better-sqlite3';
import ViteExpress from 'vite-express'
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());
const db = new Database(path.join(__dirname, 'wadsongs.db'));

const user = {
  admin: { password: "admin123", role: "admin" },
  user: { password: "user123", role: "user"}
};

app.post('/login', (req, res) =>{
  const {username, password} = req.body;
  if (user [username] && user[username].password === password) {
    res.json({ success: true , role:user[username].role });
  } else {
    res.status(401).json()({success: false, message: "Wrong Credentials" });
  }
});

app.get('/songs/all', (req, res) =>{
    const rows = db.prepare('SELECT * FROM wadsongs').all();
    res.json(rows);
});

app.get('/songs/artist/:name', (req, res) => {
    const name = req.params.name;
    const rows = db.prepare('SELECT * FROM wadsongs WHERE artist = ?').all(name);
    res.json(rows);
});

app.post('/songs/add' , (req, res) => {
  try {
    const { title, artist,year } = req.body;
    const stmt = db.prepare('INSERT INTO wadsongs (title, artist, year, quantity) VALUES (?, ?, ?, ?)');
    stmt.run(title, artist, year, 1000);
    res.json({ success: true, message: "Song added successfully" });
  } catch (error) {
    console.error('Add song error:', error.message);
    res.status(500).json({error: error.message});
  }
})



// const PORT = 3000;
ViteExpress.listen(app, 3000, () => {
console.log(`Production server running at 3000`);
});
